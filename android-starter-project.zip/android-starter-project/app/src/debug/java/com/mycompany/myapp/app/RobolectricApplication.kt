package com.mycompany.myapp.app

import android.annotation.SuppressLint
import android.app.Application

@SuppressLint("Registered")
class RobolectricApplication : Application()
