package com.mycompany.myapp.app

import android.content.Context

class Settings(context: Context) : VariantSettings(context)
