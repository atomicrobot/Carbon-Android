package com.mycompany.myapp

/**
 * See https://stackoverflow.com/a/44284452/541313
 *
 * I'm not happy about it either.
 */
@Target(AnnotationTarget.CLASS)
annotation class Mockable