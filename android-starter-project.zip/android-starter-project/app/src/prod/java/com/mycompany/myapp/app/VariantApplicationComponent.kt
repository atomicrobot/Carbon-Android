package com.mycompany.myapp.app

interface VariantApplicationComponent
