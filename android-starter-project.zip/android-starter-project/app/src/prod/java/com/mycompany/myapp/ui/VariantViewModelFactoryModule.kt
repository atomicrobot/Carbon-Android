package com.mycompany.myapp.ui

import dagger.Module

@Module
abstract class VariantViewModelFactoryModule {

}